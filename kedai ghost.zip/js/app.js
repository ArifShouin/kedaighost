document.addEventListener('alpine:init', () => {
  Alpine.data('product', () => ({
    
  }))
});